#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+5;
ll n,m;
ll a[N];
ll seg[4*N];
void build(ll node,ll l,ll r)
{
    if(l==r)
    {
        seg[node]=a[l];
        return;
    }
    ll mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    seg[node]=min(seg[2*node],seg[2*node+1]);
}
void update(ll node,ll l,ll r,ll pos,ll val)
{
    if(l==r)
    {
        seg[node]=val;
        return;
    }
    ll mid=(l+r)/2;
    if(pos<=mid)
    update(2*node,l,mid,pos,val);
    else
    update(2*node+1,mid+1,r,pos,val);
    seg[node]=min(seg[2*node],seg[2*node+1]);
}
ll query(ll node,ll l,ll r,ll ql,ll qr)
{
    if(l>=ql && r<=qr)
    return seg[node];
    else if(l>qr || r<ql)
    return 1e9+1;
    ll mid=(l+r)/2;
    return min(query(2*node,l,mid,ql,qr),query(2*node+1,mid+1,r,ql,qr));
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
    cin>>a[i];
    build(1,1,n);
    while(m--)
    {
        ll x;
        cin>>x;
        if(x==1)
        {
            ll i,val;
            cin>>i>>val;
            update(1,1,n,i+1,val);
        }
        else
        {
            ll l,r;
            cin>>l>>r;
            cout<<query(1,1,n,l+1,r)<<"\n";
        }
    }
}