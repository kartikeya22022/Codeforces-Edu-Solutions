#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+5;
ll n,m;
ll a[N];
pair<ll,ll> seg[4*N];
void build(ll node,ll l,ll r)
{
    if(l==r)
    {
        seg[node].first=a[l];
        seg[node].second=1;
        return;
    }
    ll mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    if(seg[2*node].first<seg[2*node+1].first)
    {
        seg[node].first=seg[2*node].first;
        seg[node].second=seg[2*node].second;
    }
    else if(seg[2*node].first>seg[2*node+1].first)
    {
        seg[node].first=seg[2*node+1].first;
        seg[node].second=seg[2*node+1].second;
    }
    else
    {
        seg[node].first=seg[2*node+1].first;
        seg[node].second=seg[2*node+1].second+seg[2*node].second;        
    }
    return;
}
void update(ll node,ll l,ll r,ll pos,ll val)
{
    if(l==r)
    {
        seg[node].first=val;
        seg[node].second=1;
        return;
    }
    ll mid=(l+r)/2;
    if(pos<=mid)
    update(2*node,l,mid,pos,val);
    else
    update(2*node+1,mid+1,r,pos,val);
    if(seg[2*node].first<seg[2*node+1].first)
    {
        seg[node].first=seg[2*node].first;
        seg[node].second=seg[2*node].second;
    }
    else if(seg[2*node].first>seg[2*node+1].first)
    {
        seg[node].first=seg[2*node+1].first;
        seg[node].second=seg[2*node+1].second;
    }
    else
    {
        seg[node].first=seg[2*node+1].first;
        seg[node].second=seg[2*node].second+seg[2*node+1].second;        
    }
    return;
}
pair<ll,ll> query(ll node,ll l,ll r,ll ql,ll qr)
{
    if(l>=ql && r<=qr)
    return seg[node];
    else if(l>qr || r<ql)
    return {1e9+1,0};
    ll mid=(l+r)/2;
    pair <ll,ll> p1=query(2*node,l,mid,ql,qr);
    pair <ll,ll> p2=query(2*node+1,mid+1,r,ql,qr);
    if(p1.first<p2.first)
    return p1;
    else if(p1.first>p2.first)
    return p2;
    else 
    return {p1.first,p1.second+p2.second};
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
    cin>>a[i];
    build(1,1,n);
    while(m--)
    {
        ll x;
        cin>>x;
        if(x==1)
        {
            ll i,val;
            cin>>i>>val;
            update(1,1,n,i+1,val);
        }
        else
        {
            ll l,r;
            cin>>l>>r;
            pair<ll,ll> ans=query(1,1,n,l+1,r);
            cout<<ans.first<<" "<<ans.second<<"\n";
        }
    }
}