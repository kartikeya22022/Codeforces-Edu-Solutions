#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+5;
ll n,m;
ll a[N],ans;
ll seg[4*N];
void build(ll node,ll l,ll r)
{
    if(l==r)
    {
        seg[node]=a[l];
        return;
    }
    ll mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    seg[node]=seg[2*node]+seg[2*node+1];
    return;
}
void update(ll node,ll l,ll r,ll pos)
{
    if(l==r)
    {
        a[pos]=1^a[pos];
        seg[node]=a[pos];
        return;
    }
    ll mid=(l+r)/2;
    if(pos<=mid)
    update(2*node,l,mid,pos);
    else
    update(2*node+1,mid+1,r,pos);
    seg[node]=seg[2*node]+seg[2*node+1];
    return;
}
void query(ll node,ll l,ll r,ll k)
{
    if(l==r)
    {
        ans=l;
        return;
    }
    ll mid=(l+r)/2;
    if(k>seg[2*node])
    query(2*node+1,mid+1,r,k-seg[2*node]);
    else
    query(2*node,l,mid,k);
    return;
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
    cin>>a[i];
    build(1,1,n);
    while(m--)
    {
        ll x;
        cin>>x;
        if(x==1)
        {
            ll i;
            cin>>i;
            i++;
            update(1,1,n,i);
        }
        else
        {
            ll k;
            cin>>k;
            k++;
            query(1,1,n,k);
            cout<<(ans-1)<<"\n";
        }
    }
    return 0;
}