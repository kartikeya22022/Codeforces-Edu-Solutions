#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+5;
ll n,m;
ll a[N];
ll seg[4*N],ans;
void build(ll node,ll l,ll r)
{
    if(l==r)
    {
        seg[node]=a[l];
        return;
    }
    ll mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    seg[node]=max(seg[2*node],seg[2*node+1]);
    return;
}
void update(ll node,ll l,ll r,ll pos,ll val)
{
    if(l==r)
    {
        seg[node]=val;
        a[l]=val;
        return;
    }
    ll mid=(l+r)/2;
    if(pos<=mid)
    update(2*node,l,mid,pos,val);
    else
    update(2*node+1,mid+1,r,pos,val);
    seg[node]=max(seg[2*node],seg[2*node+1]);
    return;
}
void query(ll node,ll l,ll r,ll val)
{
    if(l==r)
    {
        if(a[l]>=val)
        ans=l;
        return;
    }
    ll mid=(l+r)/2;
    if(seg[2*node]>=val)
    query(2*node,l,mid,val);
    else if(seg[2*node+1]>=val)
    query(2*node+1,mid+1,r,val);
    return;
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
    cin>>a[i];
    build(1,1,n);
    while(m--)
    {
        int x;
        cin>>x;
        if(x==1)
        {
            ll i,val;
            cin>>i>>val;
            update(1,1,n,i+1,val);
        }
        else if(x==2)
        {
            ans=0;
            ll val;
            cin>>val;
            query(1,1,n,val);
            cout<<(ans-1)<<"\n";
        }
    }
    return 0;
}