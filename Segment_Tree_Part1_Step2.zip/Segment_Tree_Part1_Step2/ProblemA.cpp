#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+6;
ll a[N];
ll n,m;
vector <vector<ll>> seg(4*N,vector<ll> (5,0));
void build(ll node,ll l,ll r)
{
    if(l==r)
    {
        seg[node][1]=a[l];
        seg[node][2]=a[l];
        seg[node][3]=a[l];
        seg[node][4]=a[l];
        return;
    }
    ll mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    seg[node][1]=seg[2*node][1]+seg[2*node+1][1];
    seg[node][2]=max(seg[2*node][2],seg[2*node][1]+seg[2*node+1][2]);
    seg[node][3]=max(seg[2*node][3]+seg[2*node+1][1],seg[2*node+1][3]);
    seg[node][4]=max({seg[2*node][4],seg[2*node+1][4],seg[2*node][3]+seg[2*node+1][2]});
    return;
}
void update(ll node,ll l,ll r,ll pos,ll val)
{
    if(l==r)
    {
        seg[node][1]=val;
        seg[node][2]=val;
        seg[node][3]=val;
        seg[node][4]=val;
        return;
    }
    ll mid=(l+r)/2;
    if(pos<=mid)
    update(2*node,l,mid,pos,val);
    else
    update(2*node+1,mid+1,r,pos,val);
    seg[node][1]=seg[2*node][1]+seg[2*node+1][1];
    seg[node][2]=max(seg[2*node][2],seg[2*node][1]+seg[2*node+1][2]);
    seg[node][3]=max(seg[2*node][3]+seg[2*node+1][1],seg[2*node+1][3]);
    seg[node][4]=max({seg[2*node][4],seg[2*node+1][4],seg[2*node][3]+seg[2*node+1][2]});
    return;
}
vector <ll> query(ll node,ll l,ll r,ll ql,ll qr)
{
    if(l>=ql && r<=qr)
    return seg[node];
    if(l>qr || r<ql)
    {
        vector <ll> arr(5,0);
        return arr;
    }
    ll mid=(l+r)/2;
    vector <ll> arr1=query(2*node,l,mid,ql,qr);
    vector <ll> arr2=query(2*node+1,mid+1,r,ql,qr);
    vector <ll> arr(5);
    arr[1]=arr1[1]+arr2[1];
    arr[2]=max(arr1[2],arr1[1]+arr2[2]);
    arr[3]=max(arr1[3]+arr2[1],arr2[3]);
    arr[4]=max({arr1[4],arr2[4],arr1[3]+arr2[2]});
    return arr;
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
    cin>>a[i];
    build(1,1,n);
    vector <ll> ans=query(1,1,n,1,n);
    ll z=0;
    ll p=max(ans[4],z);
    cout<<p<<"\n";
    while(m--)
    {
        /*ll x;
        cin>>x;
        if(x==1)
        {
            ll i,val;
            cin>>i>>val;
            i++;
            update(1,1,n,i,val);
        }
        else
        {
            ll l,r;
            cin>>l>>r;
            l++;
            vector <ll> ans=query(1,1,n,l,r);
            cout<<ans[4]<<"\n";
        }*/
        ll i,val;
        cin>>i>>val;
        i++;
        update(1,1,n,i,val);
        ans=query(1,1,n,1,n);
        p=max(ans[4],z);
        cout<<p<<"\n";
    }
    return 0;
}